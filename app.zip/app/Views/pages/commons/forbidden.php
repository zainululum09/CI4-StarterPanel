<?= $this->extend('layouts/main'); ?>
<?= $this->section('content'); ?>
<h1>Forbidden Page!</h1>
<?= $this->endSection(); ?>